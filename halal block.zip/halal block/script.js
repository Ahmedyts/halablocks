let score = 0;
let moves = 25;
let coins = 0;
let gameBoard = document.getElementById('game-board');
let scoreDisplay = document.getElementById('score-value');
let moveDisplay = document.getElementById('move-count');
let coinDisplay = document.getElementById('coin-count');
let startButton = document.getElementById('start-game');
let gameScreen = document.querySelector('.game-screen');
let homeScreen = document.querySelector('.home-screen');
let levelCompleteScreen = document.querySelector('.level-complete-screen');
let gameOverScreen = document.querySelector('.game-over-screen');
let finalScoreDisplay = document.getElementById('final-score');
let finalScoreGameOver = document.getElementById('final-score-gameover');
let useHammerButton = document.getElementById('use-hammer');
let addMovesButton = document.getElementById('add-moves');
let useCasterButton = document.getElementById('use-caster');
let nextLevelButton = document.getElementById('next-level');
let restartButton = document.getElementById('restart-btn');
let restartGameButton = document.getElementById('restart-game');

// Start Game
startButton.addEventListener('click', startGame);

// Start the game
function startGame() {
    homeScreen.style.display = 'none';
    gameScreen.style.display = 'block';
    createBoard();
    updateScore();
    updateMoves();
    updateCoins();
}

// Create the game board
function createBoard() {
    gameBoard.innerHTML = ''; // Clear the previous board

    // Create blocks for the game board (5x5 grid)
    for (let i = 0; i < 25; i++) {
        let block = document.createElement('div');
        block.classList.add('block');
        block.dataset.color = getRandomColor();
        block.style.backgroundColor = block.dataset.color;

        block.addEventListener('click', handleBlockClick);
        gameBoard.appendChild(block);
    }
}

// Get a random color for blocks
function getRandomColor() {
    const colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6'];
    return colors[Math.floor(Math.random() * colors.length)];
}

// Handle block click (for matching)
function handleBlockClick(event) {
    let clickedBlock = event.target;
    // Logic to check if it's part of a match and update score
    clickedBlock.style.backgroundColor = getRandomColor();
    score += 50;
    moves--;
    updateScore();
    updateMoves();
    checkLevelCompletion();
}

// Update score display
function updateScore() {
    scoreDisplay.textContent = score;
}

// Update move count
function updateMoves() {
    moveDisplay.textContent = moves;
}

// Update coin count
function updateCoins() {
    coinDisplay.textContent = coins;
}

// Check if the level is complete
function checkLevelCompletion() {
    // Check if the player has reached the target score (for this example, 1000 points)
    if (score >= 1000) {
        completeLevel();
    }
    // If no moves left, show failure
    if (moves <= 0) {
        gameOver();
    }
}

// Complete Level
function completeLevel() {
    coins += 500; // Earn 500 coins after completing the level
    levelCompleteScreen.style.display = 'block';
    finalScoreDisplay.textContent = score;
    updateCoins();
}

// Game Over
function gameOver() {
    gameOverScreen.style.display = 'block';
    finalScoreGameOver.textContent = score;
    gameScreen.style.display = 'none';
}

// Next Level Button
nextLevelButton.addEventListener('click', () => {
    levelCompleteScreen.style.display = 'none';
    restartGame();
});

// Restart Game Button
restartButton.addEventListener('click', restartGame);

// Restart the game
function restartGame() {
    score = 0;
    moves = 25;
    updateScore();
    updateMoves();
    createBoard();
    gameOverScreen.style.display = 'none';
    levelCompleteScreen.style.display = 'none';
    gameScreen.style.display = 'block';
}

// Power-up: Use Hammer (Smash half of the board)
useHammerButton.addEventListener('click', () => {
    if (coins >= 10000) {
        coins -= 10000;
        updateCoins();
        useHammer();
    } else {
        alert('Not enough coins for Hammer!');
    }
});

// Use Hammer to smash half of the board
function useHammer() {
    let blocks = document.querySelectorAll('#game-board .block');
    let smashedBlocks = 0;

    // Randomly select blocks to "smash"
    while (smashedBlocks < blocks.length / 2) {
        let randomBlock = blocks[Math.floor(Math.random() * blocks.length)];
        if (!randomBlock.classList.contains('smashed')) {
            randomBlock.classList.add('smashed');
            randomBlock.style.backgroundColor = '#bdc3c7'; // Grey out smashed blocks
            smashedBlocks++;
            score += 50; // Earn points for each block smashed
        }
    }
    updateScore();
}

// Power-up: Add +50 Moves
addMovesButton.addEventListener('click', () => {
    if (coins >= 1000) {
        coins -= 1000;
        moves += 50;
        updateCoins();
        updateMoves();
    } else {
        alert('Not enough coins for +50 Moves!');
    }
});

// Power-up: Use Caster (Add 20 Moves)
useCasterButton.addEventListener('click', () => {
    if (coins >= 2000) {
        coins -= 2000;
        moves += 20;
        updateCoins();
        updateMoves();
    } else {
        alert('Not enough coins for Caster!');
    }
});
